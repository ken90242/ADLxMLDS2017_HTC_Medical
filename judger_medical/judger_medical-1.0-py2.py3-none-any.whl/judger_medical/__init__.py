from collections import defaultdict
import csv
from os import path
import tempfile
from copy import copy
from datetime import datetime
import json

_root = ''        # image root directory
_answers = defaultdict(lambda: [])
                  # ground truth answers
_f = None         # the file object
_files = []       # the list of input images' file name
_all_clas = set(['Effusion', 'Pneumothorax', 'Cardiomegaly', 'Pneumonia', 'Nodule', 'Mass', 'Atelectasis', 'Infiltration'])
                  # all possible label names
_module_root = path.dirname(__file__) # the module root

# set up from root and ground truth file
def _setup(image_root, ground_truth_file):
    global _root, _files, _all_clas
    _root = image_root

    # one box per line
    with open(ground_truth_file) as f:
        for r in csv.reader(f):
            if r[0].endswith('.png'):
                img = r[0]
                clas = r[1].strip()
                x = float(r[2])
                y = float(r[3])
                w = float(r[4])
                h = float(r[5])
                _answers[path.normpath(path.join(_root, img))].append([clas, x, y, w, h])

    # generate files
    _files = list(_answers.keys())

# default setup
_setup(path.normpath(path.join(_module_root, './sample_dataset')),
       path.normpath(path.join(_module_root, './sample_dataset/sample_ground_truth.csv')))

def get_file_names():
    # returns a copy to prevent modification
    return copy(_files)

def get_output_file_object():
    global _f
    if _f is not None:
        _f.close()

    # uses temp file to ensure self destruction
    _f = tempfile.TemporaryFile()
    return _f

# calculates IoU of two boxes
# box = [x, y, w, h]
def _IoU(box1, box2):
    box1 = list(map(float, box1))
    box2 = list(map(float, box2))
    area1 = box1[2] * box1[3]
    area2 = box2[2] * box2[3]
    overlap_x = max(0.0, min(box1[0] + box1[2], box2[0] + box2[2]) - max(box1[0], box2[0]))
    overlap_y = max(0.0, min(box1[1] + box1[3], box2[1] + box2[3]) - max(box1[1], box2[1]))
    overlap_area = overlap_x * overlap_y
    return overlap_area / (area1 + area2 - overlap_area)

# check if user_box matches ground truth box with target IoU (tiou)
# box = [clas, x, y, w, h]
def _box_correct(user_box, ground_box, tiou):
    if user_box[0] != ground_box[0]:
        return False
    else:
        return (_IoU(user_box[1:5], ground_box[1:5]) >= tiou)

def judge():
    global _f

    # this is the submission time stamp
    submit_time = datetime.now()

    try:
        if _f is None:
            raise Exception("please call get_output_file_object() first")
        
        if _f.closed:
            raise Exception("please do not close the given file object")
        
        # flush and read from start
        _f.seek(0)

        # answers from user
        user_answers = {}
        
        # parse one image per loop
        while True:
            line = _f.readline().decode('ascii').strip()
            if line == '':
                break
            
            header = line.split(' ')
            if len(header) != 2:
                raise Exception("format error in image header: %s" % line)
            
            img = header[0]
            if img not in _files:
                raise Exception("image is not in the file list: %s" % img)

            if img in user_answers:
                raise Exception("image name repeated: %s" %img)

            user_answers[img] = []
            
            nbox = int(header[1])
            if nbox > 10 or nbox < 0:
                raise Exception("invalid number of box: %d" % nbox)

            # one box per loop here
            for i in range(nbox):
                line = _f.readline().decode('ascii').strip()
                box = line.split(' ')
                if len(box) != 5:
                    raise Exception("format error in box: %s" % box)
                
                clas = box[0]
                if clas not in _all_clas:
                    raise Exception("unrecognized class: %s" % clas)
                
                x = float(box[1])
                y = float(box[2])
                w = float(box[3])
                h = float(box[4])
                if x < 0 or y < 0 or w <= 0 or h <= 0:
                    raise Exception("invalid box: %f %f %f %f" % (x, y, w, h))

                user_answers[img].append([clas, x, y, w, h])

        # consistency check
        if len(user_answers) != len(_answers):
            raise Exception("number of images incorrect, expected %d, found %d"
                    % (len(_answers), len(user_answers)))

        # calculate the scores
        score_25 = 0.0
        score_50 = 0.0

        # one image per loop
        for img in _answers:
            img_score_25 = 0.0
            img_score_50 = 0.0
            # one ground truth box per loop
            for box in _answers[img]:
                box_score_25 = 0.0
                box_score_50 = 0.0
                # one user box per loop
                # check if ANY one of the user boxes match this ground truth box
                for user_box in user_answers[img]:
                    if _box_correct(user_box, box, 0.25):
                        box_score_25 = 1.0
                    if _box_correct(user_box, box, 0.50):
                        box_score_50 = 1.0

                img_score_25 += box_score_25
                img_score_50 += box_score_50
                
            img_score_25 /= len(_answers[img])
            img_score_50 /= len(_answers[img])
            score_25 += img_score_25
            score_50 += img_score_50

        score_25 /= len(_answers)
        score_50 /= len(_answers)
        score = (score_25 + score_50) / 2.0
        
        # close the file
        _f.close()
        _f = None

        # show result on screen in JSON format
        # JSON can enable auto-parsing utility in the platform
        print (json.dumps({"time": str(submit_time), "score": score}).encode('ascii'))
    except Exception as ex:
        return 0.0, str(ex)
    else:
        return score, None

