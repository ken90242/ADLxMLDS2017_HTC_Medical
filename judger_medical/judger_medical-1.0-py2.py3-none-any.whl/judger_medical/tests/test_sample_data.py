from unittest import TestCase
import os
import hashlib
import io
from collections import Counter

import judger_medical as judger

def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

class TestSampleData(TestCase):
    def assertError(self, match, score, err):
        self.assertIsInstance(err, str)        
        self.assertNotEqual(match, '')
        self.assertAlmostEqual(score, 0.0)
        self.assertTrue(all([(x in err) for x in match.split(' ')]), match + ' ' + err)
    
    def test_get_file_names(self):
        imgs = judger.get_file_names()
        self.assertIsInstance(imgs, list)
        self.assertTrue(all([isinstance(x, str) for x in imgs]))
        self.assertEqual(Counter([os.path.basename(x) for x in imgs]), Counter(['0.png', '1.png', '2.png']))
        self.assertEqual(Counter(imgs), Counter(judger.get_file_names())) # consistency
        for img in imgs:
            self.assertTrue(os.path.isfile(img) and os.access(img, os.R_OK))

    def test_fetched_files(self):
        imgs = judger.get_file_names()
        self.assertEqual({os.path.basename(x): md5(x) for x in imgs},
            {
                '0.png': '834cf09fb7543885408a445b19c46c1f',
                '1.png': 'a297ab2db9cf4f7dd5f00e2bf2c69a0c',
                '2.png': 'b958bdf7a67cc883a3a14d3b276c4619'
            }
        )
        real_answer = judger._answers
        self.assertEqual({os.path.basename(img): len(real_answer[img]) for img in real_answer},
                         {'0.png': 2, '2.png': 1, '1.png': 3})

    def test_get_output_file_object(self):
        f = judger.get_output_file_object()
        # just check by writing something
        f.write('test'.encode('ascii'))

    def test_IOU(self):
        self.assertAlmostEqual(0.0, judger._IoU([0, 0, 5, 5], [5, 5, 5, 5]))
        self.assertAlmostEqual(1.0, judger._IoU([1, 2, 7, 8], [1, 2, 7, 8]))
        self.assertAlmostEqual(1./9., judger._IoU([1, 1, 6, 6], [2, 2, 2, 2]))
        self.assertAlmostEqual(20./69., judger._IoU([3, 5, 6, 9], [4, 4, 7, 5]))

    def test_error_handling_of_file_object(self):
        self.assertError('get_output_file_object first', *judger.judge())

        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        f.close()
        self.assertError('not close', *judger.judge())

    def test_output_order(self):
        imgs = judger.get_file_names()
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 0\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(0.0 <= score and score <= 1.0)
        
        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        for img in imgs[::-1]:
            f.write((img + ' 0\n').encode('ascii'))
        new_score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(new_score, float)
        self.assertTrue(0.0 <= new_score and new_score <= 1.0)
        self.assertEqual(score, new_score)

    def test_output_missing_img(self):
        imgs = judger.get_file_names()
        f = judger.get_output_file_object()
        for img in imgs[:len(imgs) - 1]:
            f.write((img + ' 0\n').encode('ascii'))
        self.assertError('number', *judger.judge())

    def test_output_with_wrong_sizes(self):
        imgs = judger.get_file_names()
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' -1\n').encode('ascii'))
        self.assertError('number of box', *judger.judge())
        
        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 11\n').encode('ascii'))
            for _ in range(11):
                f.write('Atelectasis 0 1 2 3\n'.encode('ascii'))
        self.assertError('number of box', *judger.judge())
        
        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 0\n').encode('ascii'))
            f.write('Atelectasis 0 1 2 3\n'.encode('ascii'))
        self.assertError('format error header', *judger.judge())
        
        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 1\n').encode('ascii'))
            f.write('Atelectasis 0 1 2\n'.encode('ascii'))
        self.assertError('format error box', *judger.judge())
        
        # no reinitialize module should be safe
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 1\n').encode('ascii'))
            f.write('Atelectasis 0 -1 2 3\n'.encode('ascii'))
        self.assertError('invalid box', *judger.judge())

    def test_normal_output(self):
        imgs = judger.get_file_names()
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 10\n').encode('ascii'))
            for _ in range(10):
                f.write('Atelectasis 0 1 2 3\n'.encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertIsInstance(score, float)
        self.assertTrue(0.0 <= score and score <= 1.0)

    def test_wrong_class(self):
        imgs = judger.get_file_names()
        f = judger.get_output_file_object()
        for img in imgs:
            f.write((img + ' 1\n').encode('ascii'))
            f.write('Cat 0 1 2 3\n'.encode('ascii'))
        self.assertError('unrecognized class', *judger.judge())

    def test_class_names(self):
        self.assertEqual(Counter(list(judger._all_clas)),
                         Counter(['Effusion', 'Pneumothorax', 'Cardiomegaly', 'Pneumonia', 'Nodule', 'Mass', 'Atelectasis', 'Infiltration']))
        self.assertEqual(len(judger._all_clas), 8)

    def test_scores(self):
        imgs = judger.get_file_names()
        real_answers = judger._answers
        
        # no reinitialize module should be safe
        # test perfect
        f = judger.get_output_file_object()
        for img in real_answers:
            f.write((img + ' ' + str(len(real_answers[img])) + '\n').encode('ascii'))
            for box in real_answers[img]:
                f.write((' '.join(map(str, box)) + '\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertEqual(score, 1.0)

        # test perfect with extra boxes
        f = judger.get_output_file_object()
        for img in real_answers:
            f.write((img + ' ' + str(len(real_answers[img]) * 2) + '\n').encode('ascii'))
            for box in real_answers[img]:
                f.write((' '.join(map(str, box)) + '\n').encode('ascii'))
                f.write((box[0] + ' 1 2 3 4\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertEqual(score, 1.0)

        # test box perfect but class mismatch
        f = judger.get_output_file_object()
        for img in real_answers:
            f.write((img + ' ' + str(len(real_answers[img])) + '\n').encode('ascii'))
            for box in real_answers[img]:
                f.write(('Cardiomegaly ' + ' '.join(map(str, box[1:])) + '\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertEqual(score, 0.0)
        
        # test class perfect but no box correct
        f = judger.get_output_file_object()
        for img in real_answers:
            f.write((img + ' ' + str(len(real_answers[img])) + '\n').encode('ascii'))
            for box in real_answers[img]:
                f.write((box[0] + ' 0 1 2 3\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertEqual(score, 0.0)

        # test partial correct
        f = judger.get_output_file_object()
        for img in imgs:
            n = len(real_answers[img])
            f.write((img + ' 1\n').encode('ascii'))
            f.write((' '.join(map(str, real_answers[img][0])) + '\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertAlmostEqual(score, 1./3. + 1./6. + 1./9.)
        
        # test different rois
        f = judger.get_output_file_object()
        for img, iou in zip(imgs, [0.24, 0.26, 0.51]):
            n = len(real_answers[img])
            f.write((img + ' ' + str(n) + '\n').encode('ascii'))
            for box in real_answers[img]:
                f.write((' '.join(map(str, box[:4]))).encode('ascii'))
                R = box[4] * iou
                f.write((' ' + str(R) + '\n').encode('ascii'))
        score, err = judger.judge()
        self.assertEqual(err, None)
        self.assertAlmostEqual(score, 2./6. + 1./6.) 
