Judger_Medical
==============
| The judger of the NTU ML final project - weakly supervised learning on medical images.
| You must import this package and use the functions accordingly when submitting your solution.

Getting Started
===============
Please use pip or pip3 to install this package as follows.

.. code::

    $pip install judger_medical-(version)-py2.py3-none-any.whl

Running the Tests
=================
Using nosetests_ to run the built-in tests is recommended.

.. _nosetests: http://nose.readthedocs.io/en/latest/

.. code::

    $pip install nose
    $nosetests judger_medical
    or
    $python -m 'nose' judger_medical

APIs
====

get_file_names()
----------------
| Returns a list of strings.
| Each string in the list is an absolute path to an input image.
| All returned strings are unique.
| This list is considered the test dataset.

Special Note
~~~~~~~~~~~~
- The image set in this distributed version contains only three images extracted from the previously announced validation set.
- The images are from `NIH Chest X-ray dataset`_.

.. _NIH Chest X-ray dataset: https://nihcc.app.box.com/v/ChestXray-NIHCC

get_output_file_object()
------------------------
| Returns a file-like object to which you should write your output.
| Please refer to Output Format section for the format of your output.

Speical Note
~~~~~~~~~~~~
- You must **NOT** close the returned file-like object.
- In the submission site, you must not delete or reopen the underlying file.

judge()
-------
| Returns your score and an error message.
| If we failed to judge your output, error will be a string and score will be 0.
| Otherwise, error is None and your score will be a floating point number between 0 and 1.
| In the latter case, this function outputs a json formatted string to stdout containing your score and the submission timestamp.

Special Note
~~~~~~~~~~~~
- You should call this function **AFTER** a call to get_output_file_object().
- The timestamp generated when calling this function will be used to determine if this submission is on time.
- This function writes to stdout, you should NOT redirect stdout in your program.

Output Format
=============

Overall Structure
-----------------
The output is composed of consecutive <image block>s.

.. code::

    <image block 1>
    <image block 2>
    ...
    <image block N>

- The <image block>s in the output can be at any order.
- For each input image, exactly one <image block> is required.

Image Block
-----------
Each <image block> contains the prediction of a single input image, it is composed of a header followed by consecutive <box block>s.

.. code::

    <image file path> <number of boxes>
    <box block 1>
    <box block 2>
    ...
    <box block M>

- <image file path> should be identical to (one of the strings of) the output of get_file_names().
- <number of boxes> should be an integer between 0 and 10.
- The number of the following <box block>s should match the <number of boxes>.

Box Block
---------
Each <box block> contains the prediction of a single bounding box.

.. code::

    <class name> <x> <y> <w> <h>

- <class name> should be one of the following **8** classes, this string **is** case sensitive.

  - Effusion
  - Pneumothorax
  - Cardiomegaly
  - Pneumonia
  - Nodule
  - Mass
  - Atelectasis
  - Infiltration
- <x>, <y>, <w>, and <h> should be four floating point numbers defining a box's **top left** corner (<x>, <y>), width <w>, and height <h> respectively.
- <x> and <y> should be non-negative while <w> and <h> should be positive.
- You may output floating point numbers to any proper precision without exhausting disk, ram and run time limits, we will use python's built-in float() to convert strings to floating point numbers.
- The top left corner (**not the center of the top left pixel**) of the image is defined as (0, 0) and the bottom right corner is defined as (1024, 1024).

Sample Output
-------------

.. code::

    /path/to/0.png 0
    /path/to 1.png 1
    Atelectasis 0.0 0.0 1.3 2.4
    /path/to 2.png 3
    Effusion 1.1 2.2 3.3 4.4
    Infiltration 12.3 23.4 34.5 45.6
    Pneumonia 123.0 234.0 3.0 4.0

Sample Usage
============
This code demos the functionality of this package, you are free to choose between implementing your own version and adapting this piece of code.

.. code:: python

    import judger_medical as judger
    imgs = judger.get_file_names()
    f = judger.get_output_file_object()
    for img in imgs:
        img_data = read_image_by_filename(img)
        answer = inference(img_data)
        f.write('%s %d\n' % (img, answer.number_of_boxes))
        for box in answer.boxes:
            f.write('%s %f %f %f %f\n' % (box.class_name, box.x, box.y, box.w, box.h))
    score, err = judger.judge()
    if err is not None:  # in case we failed to judge your submission
        print err

Contact
=======

For any questions, please send an email to HaoCheng_Kao [at] htc [dot] com.



